import type { NodeServices } from "@effect/platform-node"
import { Array, Effect, identity, Layer, Path, pipe, Schema as S, Semaphore } from "effect"
import { DecisionModel, LanguageModel } from "effect/ai"
import { HttpClient } from "effect/http"

import { ProjectPaths } from "./ProjectPaths.ts"
import { TraitsContext } from "./TraitsContext.ts"

export type TraitsConfig = typeof TraitsConfig.Encoded
export const TraitsConfig = S.Struct({
  decisionConcurrency: S.Union([S.Int.check(S.isGreaterThan(0)), S.Literal("unbounded")])
    .pipe(S.withDecodingDefault(Effect.succeed(4)))
    .annotate({
      description: "Maximum concurrent decision model requests, or unbounded for no limit. Defaults to 4."
    }),
  excludeGitignored: S.Boolean.pipe(S.withDecodingDefault(Effect.succeed(true))).annotate({
    description: "Exclude Git-ignored files from checks by default. Set false to disable the Git file-set filter."
  }),
  excludes: S.Array(S.NonEmptyString)
    .pipe(S.withDecodingDefault(Effect.succeed([])))
    .annotate({
      description:
        "Filenames or native filesystem glob patterns excluded from trait checks, relative to traits.ts or absolute. Use directory/** to exclude a subtree. Bare directories are not expanded; escape glob characters in literal filenames using native glob syntax."
    }),
  fileReadConcurrency: S.Union([S.Int.check(S.isGreaterThan(0)), S.Literal("unbounded")])
    .pipe(S.withDecodingDefault(Effect.succeed(16)))
    .annotate({
      description:
        "Maximum concurrent trait-file reads during scans and reconciliation. Defaults to 16. Unbounded explicitly removes the limit."
    }),
  layerDecisionModel: S.declare(
    (
      value
    ): value is Layer.Layer<DecisionModel.DecisionModel, any, NodeServices.NodeServices | HttpClient.HttpClient> =>
      Layer.isLayer(value)
  ),
  layerLanguageModel: S.declare(
    (
      value
    ): value is Layer.Layer<LanguageModel.LanguageModel, any, NodeServices.NodeServices | HttpClient.HttpClient> =>
      Layer.isLayer(value)
  )
})

export const layer = Effect.gen(function* () {
  const path = yield* Path.Path
  const { projectRoot } = yield* ProjectPaths
  const configRoot = projectRoot
  const url = yield* path.toFileUrl(path.join(configRoot, "traits.ts"))
  const module = yield* Effect.promise(() => import(url.href))
  const config = yield* pipe(module.default, S.decodeUnknownEffect(TraitsConfig))
  return Layer.mergeAll(
    // oxlint-disable-next-line effecttsgo/any-unknown-in-error-context
    config.layerDecisionModel.pipe(Layer.orDie),
    // oxlint-disable-next-line effecttsgo/any-unknown-in-error-context
    config.layerLanguageModel.pipe(Layer.orDie),
    Layer.effect(
      TraitsContext,
      Effect.gen(function* () {
        // check_traits globs absolute include patterns, and Effect matches excludes in the same coordinates.
        const excludes = Array.map(
          Array.appendAll(
            Array.flatMap([".git", ".worktrees"], (directory) => [`**/${directory}`, `**/${directory}/**`]),
            config.excludes
          ),
          (pattern) => (path.isAbsolute(pattern) ? pattern : `${configRoot}${path.sep}${pattern}`)
        )
        const asDecision =
          config.decisionConcurrency === "unbounded"
            ? identity
            : yield* Semaphore.make(config.decisionConcurrency).pipe(
                Effect.map((semaphore) => semaphore.withPermits(1))
              )
        const asFileRead =
          config.fileReadConcurrency === "unbounded"
            ? identity
            : yield* Semaphore.make(config.fileReadConcurrency).pipe(
                Effect.map((semaphore) => semaphore.withPermits(1))
              )
        return { config, configRoot, excludes, asDecision, asFileRead }
      })
    )
  )
}).pipe(Layer.unwrap)
