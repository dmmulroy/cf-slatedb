import { LibsqlClient } from "@effect/sql-libsql"
// Drizzle currently exposes programmatic SQLite schema push through this Payload integration entry point.
// Keep this adapter isolated; revisit when Drizzle offers a stable standalone schema-push API.
import { pushSchema } from "drizzle-kit/payload/sqlite"
import * as LibsqlDrizzle from "drizzle-orm/effect-libsql"
import { Array, Context, Effect, FileSystem, Layer, Path, Schema as S } from "effect"

import { relations, T } from "./tables/index.ts"
import * as WorkspacePaths from "./WorkspacePaths.ts"

export class TraitDatabase extends Context.Service<
  TraitDatabase,
  LibsqlDrizzle.EffectLibsqlDatabase<typeof relations> & { readonly $client: LibsqlClient.LibsqlClient }
>()("traits/TraitDatabase") {}

export class SchemaPushError extends S.TaggedError<SchemaPushError>()("SchemaPushError", { cause: S.Defect() }) {}

/** Opens a libSQL client and pushes the complete schema, dropping tables the schema no longer defines. */
export const makeClient = Effect.fnUntraced(function* (url: string, schema: Record<string, unknown>) {
  const client = yield* LibsqlClient.make({ url })
  // Contended writers wait for the lock rather than failing; TraitWriteLock relies on this.
  yield* client.unsafe("PRAGMA busy_timeout = 10000")
  yield* client.unsafe("PRAGMA journal_mode = WAL")
  yield* client.unsafe("PRAGMA foreign_keys = ON")
  // Serialize complete-schema initialization across collector, MCP, and query processes.
  yield* Effect.gen(function* () {
    const services = yield* Effect.context<never>()
    const runPromise = Effect.runPromiseWith(services)
    yield* Effect.tryPromise({
      try: (signal) =>
        pushSchema(schema, {
          query: <T>(query: string, params?: Array<unknown>) =>
            client.unsafe(query, params).pipe(
              Effect.map((rows) => Array.fromIterable(rows) as Array<T>),
              (effect) => runPromise(effect, { signal })
            ),
          run: (query) => client.unsafe(query).pipe(Effect.asVoid, (effect) => runPromise(effect, { signal })),
          batch: (statements) =>
            Effect.forEach(statements, (query) => client.unsafe(query), { discard: true }).pipe((effect) =>
              runPromise(effect, { signal })
            )
        }).then((migration) => migration.apply()),
      catch: (cause) => SchemaPushError.make({ cause })
    })
  }).pipe(client.withTransaction)
  return client
})

const make = Effect.fnUntraced(function* (url: string) {
  const client = yield* makeClient(url, T)
  return yield* LibsqlDrizzle.makeWithDefaults({ relations }).pipe(
    Effect.provideService(LibsqlClient.LibsqlClient, client)
  )
})

/** Isolated storage for tests and benchmarks; CLI processes use layerLocal. */
export const layer = Layer.effect(TraitDatabase, make("file::memory:"))

export const layerFile = (filename: string) =>
  Layer.effect(
    TraitDatabase,
    Effect.gen(function* () {
      const fs = yield* FileSystem.FileSystem
      const path = yield* Path.Path
      yield* fs.makeDirectory(path.dirname(filename), { recursive: true })
      const url = yield* path.toFileUrl(filename)
      return yield* make(url.href)
    })
  )

export const layerLocal = WorkspacePaths.resolve.pipe(
  Effect.map((paths) => layerFile(paths.database)),
  Layer.unwrap
)
